#Git

##Introduction
* What is Git?
* What is Github?
* Why should you care?
* Novel Writing Analogy
* Installing Git(not really)

#Git Basics
* Git init
* Git status
* Git add
* Git commit

#Git Checkout
* Git Log
* Git Checkout
* git revert --no-commit 0766c053..HEAD
    
   HEAD
    O -> O -> O -> O
                   Master

#Cloning and Github Intro
* What is Github?
* Cloning an existing repo

#Pushing to Github
* Creating a repo on github
* Adding a remote
* Pushing to github

